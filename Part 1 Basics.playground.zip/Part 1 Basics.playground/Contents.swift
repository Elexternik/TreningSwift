
var i = 1
var countMyQ: [Character] = Array(repeating: "Q", count: 20)
var height = 5
var wight = 1...(countMyQ.count-2)
var myQ = countMyQ

while i <= height{
    if i != 1 && i != height{
        for new in wight {
            countMyQ[new] = " "
            if new == (countMyQ.count - 2) {
                print(String(countMyQ))
            }
        }
    
    }
    else {
            print(String(myQ))
        }
    i += 1
    }


